The GitLab logo and wordmark artwork are licensed under a [Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-nc-sa/4.0/)

---

GITHUB®, the GITHUB® logo design, OCTOCAT® and the OCTOCAT® logo design are exclusive trademarks registered in the United States by GitHub, Inc.

The OCTOCAT design is the exclusive property of GitHub, Inc and has been federally registered with the United States Copyright Office. All rights reserved.

No adaptation or use of any kind of any of our registered trademarks or copyrights, or any other contents of this website, is allowed without the express written permission of GitHub, Inc.

Per the GitHub logo usage guidelines, we use the Octocat or GitHub logo to link to GitHub.

---

TWITTER, TWEET, RETWEET and the Twitter logo are trademarks of Twitter, Inc. or its affiliates.

---

link by DAVIVONGSA PATHRPOL from the Noun Project is licensed under a [Creative Commons Attribution 3.0 International License](https://creativecommons.org/licenses/by/3.0/)

---

Outreachy bot avatars are licensed under a [Creative Commons Attribution 4.0 International License](http://creativecommons.org/licenses/by/4.0/)
